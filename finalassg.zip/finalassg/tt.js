const readline = require('readline');
const fs = require('fs');
const rl = readline.createInterface({
input: fs.createReadStream('Indicators.csv')
});
var ii;
var counter = 0;
var jArray=[];
var header=[];
var kArray = [];
 var arr=[];
 var ind;
var final_obj={};
var index_countryname,index_indicatorname,index_year,index_value;
var Asian_Country = ["Arab World","East Asia & Pacific (all income levels)","East Asia & Pacific (developing only)",
"South Asia","Afghanistan","Armenia","Azerbaijan","Bahrain","Bangladesh","Bhutan","Brunei Darussalam","Cambodia","China",
"Georgia","Indonesia","Iran, Islamic Rep.","Iraq","Israel","Japan","Jordan","India"];
var obj_Urban = {};

var tot=[];
var arry=[];
for(ii=0;ii<Asian_Country.length;ii++)
{
  tot[ii]=0;
}


rl.on('line', function (line) {
if (counter === 0)
{
 header=line.split(',');
 index_countryname = header.indexOf('CountryName');
 index_indicatorname = header.indexOf('IndicatorName');
 index_year = header.indexOf('Year');
 index_value = header.indexOf('Value');
  counter = 1;
}

   var myNewLine=line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);

 if((myNewLine[index_countryname] =="India") && ((myNewLine[index_indicatorname] =="Urban population (% of total)") || (myNewLine[index_indicatorname] =="Rural population (% of total population)")))
{

  final_obj[header[index_countryname]]=myNewLine[index_countryname];
  final_obj[header[index_indicatorname]]=myNewLine[index_indicatorname];
  final_obj[header[index_value]]=myNewLine[index_value];
  final_obj[header[index_year]]=myNewLine[index_year];
  jArray.push(final_obj);
//console.log(final_obj[index_countryname]);
}

  final_obj={};



 var u=0;
 var r=0;
 if((Asian_Country.indexOf(myNewLine[index_countryname])!=-1)&&(myNewLine[index_indicatorname] =="Urban population"||myNewLine[index_indicatorname] =="Rural population"))
 {
   //console.log("+++++++++++++++");

   if(arr.length==0)
   {

     var objj={};
     objj["year"]=myNewLine[index_year];
     //console.log(myNewLine[3]);
     if(myNewLine[index_indicatorname]=="Urban population")
     {
       objj["UP"]=parseFloat(myNewLine[index_value]);
       objj["RP"]=0;

       //console.log(objj);
     }
     else if(myNewLine[index_indicatorname]=="Rural population")
     {
       objj["RP"]=parseFloat(myNewLine[index_value]);
       objj["UP"]=0;


     }
     arr.push(objj);
     //console.log(arr);
   }
   else
   {

     for(ind=0;ind<arr.length;ind++)
     {

       if(arr[ind].year==myNewLine[index_year])
       {
         if(myNewLine[index_indicatorname]=="Urban population")
         {
           arr[ind]["UP"]+=parseFloat(myNewLine[index_value]);
         }
         else if(myNewLine[index_indicatorname]=="Rural population")
         {
           arr[ind]["RP"]+=parseFloat(myNewLine[index_value]);
         }
         break;
       }
     }
     if(ind==arr.length)
     {
       var objj={};
       objj["year"]=myNewLine[index_year];
       if(myNewLine[index_indicatorname]=="Urban population")
       {
         objj["UP"]=parseFloat(myNewLine[index_value]);
         objj["RP"]=0;
       }
       else if(myNewLine[index_indicatorname]=="Rural population")
       {
         objj["RP"]=parseFloat(myNewLine[index_value]);
         objj["UP"]=0;
       }
       arr.push(objj);
     }
   }
 }
 /*
if(arr.length==0)
{
  var obj2={};
  obj2.year=myNewLine[index_year];



  //ind=Asian_Country.indexOf(myNewLine[index_countryname]);
  if(Asian_Country.indexOf(myNewLine[index_countryname]) != -1 && (myNewLine[index_indicatorname] == 'Urban population'))
  {

    //tot[ind]=tot[ind]+parseFloat(myNewLine[index_value]);
    //obj_Urban[header[index_countryname]]=myNewLine[index_countryname];
    obj_Urban[header[index_value]]=myNewLine[index_value];
  obj_Urban[header[index_year]]=myNewLine[index_year];

      kArray.push(obj_Urban);
  }
}
  obj_Urban={};
  */
  /*
 if(Asian_Country.indexOf(myNewLine[index_countryname]) != -1 && myNewLine[index_indicatorname] == 'Urban population (% of total)')
 {

   tot[ind]+=parseFloat(myNewLine[index_value]);
   obj_Urban[header[index_countryname]]=myNewLine[index_countryname];
   obj_Urban[header[index_indicatorname]]=myNewLine[index_indicatorname];
   obj_Urban[header[index_value]]=myNewLine[index_value];
   obj_Urban[header[index_year]]=myNewLine[index_year];

     kArray.push(obj_Urban);
 }
 obj_Urban={};
 if(Asian_Country.indexOf(myNewLine[index_countryname]) != -1 && myNewLine[index_indicatorname] == 'Rural population (% of total population)')
 {
   tot[ind]+=parseFloat(myNewLine[index_value]);
   obj_Rural[header[index_countryname]]=myNewLine[index_countryname];
   obj_Rural[header[index_indicatorname]]=myNewLine[index_indicatorname];
   obj_Rural[header[index_value]]=myNewLine[index_value];
   obj_Rural[header[index_year]]=myNewLine[index_year];
     kArray.push(obj_Rural);
 }
 obj_Rural={};
 */

/*for(var propt in obj_Urban)
{}
var object = {};
object["Year"]=propt;
object["Value"]=obj_Urban[propt];
object["IndicatorName"]="Urban";
kArray.push(object);
//console.log(propt);
}
// For pushing the values into array
for(var propt in obj_Rural)
{
var object = {};
object["Year"]=propt;
object["Value"]=obj_Rural[propt];
object["IndicatorName"]="Rural";
kArray.push(object);
}*/
//For sorting based on values(desending order)
/*kArray.sort(function(a,b)
{
   return b['Value']-a['Value'];
});*/
//console.log(kArray);
//Write


//}*/
});
 rl.on('close', function (){
 //var file = 'population.json';
 var obj = JSON.stringify(jArray);
// console.log(obj);
 fs.writeFile('population.json',obj);

/*for(ii=0;ii<kArray.length;ii++)
{
  //console.log("***********");
    kArray[ii].totpop=tot[Asian_Country.indexOf(kArray[ii][header[index_countryname]])];
    console.log(kArray[ii].totpop);
}

kArray.sort(function(a,b){
  return b.totpop-a.totpop;
});
*/
var obj1=JSON.stringify(kArray);
//console.log(obj1);
fs.writeFile('Asiaa.json',obj1);

//console.log(arr);

for(ind=0;ind<arr.length;ind++)
{
  arr[ind].RP/=Asian_Country.length;
  arr[ind].UP/=Asian_Country.length;
}

var obj2=JSON.stringify(arr);
fs.writeFile('second.json',obj2);



});
